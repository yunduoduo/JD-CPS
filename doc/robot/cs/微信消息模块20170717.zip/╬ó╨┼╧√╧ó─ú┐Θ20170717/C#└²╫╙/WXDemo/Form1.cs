﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WXDemo
{
    public partial class Form1 : Form
    {
        /*
         * 引用wx.dll文件 
         * 如果需要免注册调用可使用 WX.manifest 文件 （xp pack2 及以上版本应该都支持，其他版本自行测试）
         */
        WX.Sender ww = new WX.Sender();

        public Form1()
        {
            InitializeComponent();
        }

        private void cmdSendText_Click(object sender, EventArgs e)
        {
            /*
             * 内部执行完一步操作后 延时的时间 单位为毫秒 
             * （组件内部默认为200毫秒，可以根据电脑配置自行调整）
             */
            ww.DelayMS = 200;

            /*
             *  @param1 是要发送的内容 
             *  @param2 是被发送窗口的caption或者hwnd 
             *          （为caption时当标题有空格或者escape编码后为%uE开头的emoji表情的话 pc端自带的表情会以eg. [大笑] 的形式出现）
             *  @param3 0 表示发文字
             *          1 表示发图片 （发图片时参数1填图片路径）
             *   
             *  @return boolean 发送成功与否（这里指的是是否找到对应的对话框，具体消息是否完成在这里不做判断）
             */
            ww.WXSend ("文件传输助手","文件传输助手",0);
        }

        private void cmdGetHwnd_Click(object sender, EventArgs e)
        {
            /*
             *  获取所有拉出来的对话窗口Caption 以 | 作为分隔符
             */
            MessageBox.Show(ww.GetWeChatCaption());
            /*
             *  获取所有拉出来的对话窗口 hwnd 以 | 作为分隔符
             */
            MessageBox.Show(ww.GetWeChatHwnd());
        }
    }
}
