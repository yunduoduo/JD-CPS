﻿namespace WXDemo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdSendText = new System.Windows.Forms.Button();
            this.cmdGetHwnd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmdSendText
            // 
            this.cmdSendText.Location = new System.Drawing.Point(12, 92);
            this.cmdSendText.Name = "cmdSendText";
            this.cmdSendText.Size = new System.Drawing.Size(167, 64);
            this.cmdSendText.TabIndex = 0;
            this.cmdSendText.Text = "SendText";
            this.cmdSendText.UseVisualStyleBackColor = true;
            this.cmdSendText.Click += new System.EventHandler(this.cmdSendText_Click);
            // 
            // cmdGetHwnd
            // 
            this.cmdGetHwnd.Location = new System.Drawing.Point(12, 12);
            this.cmdGetHwnd.Name = "cmdGetHwnd";
            this.cmdGetHwnd.Size = new System.Drawing.Size(167, 64);
            this.cmdGetHwnd.TabIndex = 1;
            this.cmdGetHwnd.Text = "GetHwnd or Caption";
            this.cmdGetHwnd.UseVisualStyleBackColor = true;
            this.cmdGetHwnd.Click += new System.EventHandler(this.cmdGetHwnd_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(193, 176);
            this.Controls.Add(this.cmdGetHwnd);
            this.Controls.Add(this.cmdSendText);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cmdSendText;
        private System.Windows.Forms.Button cmdGetHwnd;
    }
}

