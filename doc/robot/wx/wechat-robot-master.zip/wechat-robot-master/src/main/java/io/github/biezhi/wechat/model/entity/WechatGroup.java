package io.github.biezhi.wechat.model.entity;

public class WechatGroup {

}
