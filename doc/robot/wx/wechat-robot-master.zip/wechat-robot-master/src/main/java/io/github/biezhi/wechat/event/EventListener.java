package io.github.biezhi.wechat.event;

public interface EventListener {

    void handleEvent(Event e);

}