package io.github.biezhi.wechat.robot;

public interface Robot {

    String talk(String msg);

}
