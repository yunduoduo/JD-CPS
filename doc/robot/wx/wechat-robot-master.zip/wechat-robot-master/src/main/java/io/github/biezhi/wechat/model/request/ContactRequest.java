package io.github.biezhi.wechat.model.request;

/**
 * @author biezhi
 *         15/06/2017
 */
public class ContactRequest {
}
