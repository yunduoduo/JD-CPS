package io.github.biezhi.wechat.event;

public class Event {

    public EventType eventEventType;

    public Event(EventType eventEventType) {
        this.eventEventType = eventEventType;
    }

}