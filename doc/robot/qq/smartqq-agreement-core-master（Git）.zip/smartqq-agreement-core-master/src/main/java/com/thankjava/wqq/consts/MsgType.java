package com.thankjava.wqq.consts;

/**
 * 消息类型
* <p>Function: PollMsgType</p>
* <p>Description: </p>
* @author zhaoxy@thankjava.com
* @date 2016年12月26日 下午7:04:54
* @version 1.0
 */
public enum MsgType {

	
	message, // f2f
	discu_message, // discu
	group_message //group
	
	
}
