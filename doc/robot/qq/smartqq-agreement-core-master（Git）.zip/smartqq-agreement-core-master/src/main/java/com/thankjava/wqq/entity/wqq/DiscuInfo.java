package com.thankjava.wqq.entity.wqq;

public class DiscuInfo {

	private long did;
	private String name;
	
	public long getDid() {
		return did;
	}
	public void setDid(long did) {
		this.did = did;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
