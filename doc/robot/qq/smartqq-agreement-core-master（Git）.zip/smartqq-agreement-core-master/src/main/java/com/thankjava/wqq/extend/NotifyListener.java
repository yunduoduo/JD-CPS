package com.thankjava.wqq.extend;

import com.thankjava.wqq.entity.msg.PollMsg;

public interface NotifyListener {
	
	public void hander(PollMsg pollMsg);
	
}
